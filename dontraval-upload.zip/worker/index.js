export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
        },
      });
    }

    if (request.method === "POST") {
      try {
        const formData = await request.formData();
        const file = formData.get("file");
        const folder = formData.get("folder") || "uploads";

        if (!file) return new Response("No file uploaded", { status: 400 });

        const key = `${folder}/${file.name}`;
        await env.MY_R2_BUCKET.put(key, file.stream());

        const fileUrl = `https://${env.CF_ACCOUNT_ID}.r2.cloudflarestorage.com/${env.MY_R2_BUCKET_NAME}/${key}`;

        return new Response(JSON.stringify({ success: true, url: fileUrl }), {
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
          },
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), {
          status: 500,
          headers: { "Content-Type": "application/json" },
        });
      }
    }

    return new Response("Method Not Allowed", { status: 405 });
  },
};
