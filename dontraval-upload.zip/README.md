# Dontraval Upload API + Frontend

This project provides:
- A Cloudflare Worker that uploads files to R2 storage.
- A simple HTML uploader to connect to the Worker.

## Setup

1. Deploy the Worker on Cloudflare.
2. Replace your Worker endpoint in `frontend/index.html`.
3. Upload both folders (`worker` + `frontend`) to your GitHub repo.
